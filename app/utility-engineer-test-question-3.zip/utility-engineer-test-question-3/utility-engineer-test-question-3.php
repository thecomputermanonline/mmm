<?php

/**
 * Plugin Name: My Result Plugin
 * Plugin URI: https://github.com/codemyviews/utlity-engineer-test/blob/master/data.csv
 * Description:  Resukt  plugin that I have  created for  test.
 * Version: 1.0
 * Author: Emmanuel AROWOSELU
 * Author URI: http://github.com/thecomputermanonline
 */


class cli_result extends WP_CLI_Command {



    /**
     * Display the answer to question 3 of https://github.com/codemyviews/utlity-engineer-test/blob/master/data.csv.
     */

    function answer()
    {


    $soundcloud = [
    'https://api.soundcloud.com/tracks/910291',
    'https://api.soundcloud.com/tracks/5678',
    'https://api.soundcloud.com/tracks/12345'
    ];
    $different_url = [
    'https://api.different-embed.com/12345',
    'https://api.different-embed.com/562222278',
    'https://api.different-embed.com/89999999'
    ];


    $strings = [
    'Some random string that also has this string: [soundcloud url="https://api.soundcloud.com/tracks/910291" params="auto_play=false&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false&amp;visual=true" width="100%" height="450" iframe="true" /] in it.',

    'Another completely random string that also has this string: [soundcloud url="https://api.soundcloud.com/tracks/5678?secret=test" params="auto_play=false&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false&amp;visual=true" width="100%" height="450" iframe="true" /] in it test .',

    'Something else completely random string that also has this string: [soundcloud url="https://api.soundcloud.com/tracks/12345?secret=test" params="auto_play=false&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false&amp;visual=true" width="100%" height="450" iframe="true" /] in i112222t.'
    ];
    $count = 0;
    while ($count < count($strings)) {

    $result[] =  str_replace($soundcloud[$count], $different_url[$count], $strings[$count]);

    $count++;

    }
        WP_CLI::line($result) ;

    }

}

WP_CLI::add_command( 'answer', 'cli_result' );

//after installing the plugin run wp result cli_result
// make sure that you have installed the WP CLI in your OS

//you can go further to collect parametes of diffrent strings for the constanst used in the function
// not sure if you will be  looking for that so i save sometime there


